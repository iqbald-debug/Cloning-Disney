<svg width="6" height="10" viewBox="0 0 6 10" fill="none" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <path d="M0.875 9.25L5.125 5L0.875 0.75" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
<?php /**PATH /Users/iqbal/Downloads/tubes/vendor/laravel/framework/src/Illuminate/Foundation/resources/exceptions/renderer/components/icons/chevron-right.blade.php ENDPATH**/ ?>